let mem=document.getElementById("counter");
// console.log(mem);

let saveel=document.getElementById("final");
let count=0;
function increment()
{
    count=count+1;
    mem.innerHTML=count;
    
    
}


function save()
{
let countstr=count+"-";
saveel.innerText+=countstr;
mem.innerHTML=0;

}



// let arr=[2,5,7,8,6,8,7,5,44,46,55,]

// let newarray=arr.filter((val)=>{
// console.log( val%2!==0);

// });